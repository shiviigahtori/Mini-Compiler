import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import subprocess
import tempfile
import os

CPP_EXECUTABLE = "./mini_compiler"  # Change to your actual compiled C++ executable

class CompilerUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Mini Compiler IDE")
        self.filename = None
        
        # Dark theme colors
        self.bg_color = "#2d2d2d"
        self.button_color = "#3c3f41"
        self.button_active = "#4e5254"
        self.text_bg = "#1e1e1e"
        self.text_fg = "#d4d4d4"
        self.highlight_color = "#3a3d41"
        self.accent_color = "#569cd6"
        self.status_bg = "#252526"
        self.status_fg = "#b5b5b5"
        
        # Configure root window
        self.root.configure(bg=self.bg_color)
        self.root.minsize(800, 700)
        
        # Custom style configuration
        self.configure_styles()
        
        # Create main frames
        self.top_frame = tk.Frame(root, bg=self.bg_color)
        self.top_frame.pack(pady=10, padx=10, fill=tk.X)
        
        self.middle_frame = tk.Frame(root, bg=self.bg_color)
        self.middle_frame.pack(pady=5, padx=10, fill=tk.X)
        
        self.bottom_frame = tk.Frame(root, bg=self.bg_color)
        self.bottom_frame.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)
        
        # File controls
        file_frame = tk.Frame(self.top_frame, bg=self.bg_color)
        file_frame.pack(side=tk.LEFT, padx=5)
        
        self.open_btn = ttk.Button(file_frame, text="📂 Open .mini File", command=self.open_file, style='Accent.TButton')
        self.open_btn.pack(side=tk.LEFT, padx=2)
        
        self.save_btn = ttk.Button(file_frame, text="💾 Save", command=self.save_file)
        self.save_btn.pack(side=tk.LEFT, padx=2)
        
        self.clear_btn = ttk.Button(file_frame, text="❌ Clear", command=self.clear_code)
        self.clear_btn.pack(side=tk.LEFT, padx=2)
        
        # File name label
        self.file_label = tk.Label(self.top_frame, text="No file loaded", bg=self.bg_color, fg="#a0a0a0")
        self.file_label.pack(side=tk.RIGHT, padx=10)
        
        # Phase buttons
        self.phase_btns = []
        phases = [
            ("🔤 Tokenize", "tokenize"),
            ("📊 Parse", "parse"),
            ("🧠 Semantic", "semantic"),
            ("📝 TAC", "tac"),
            ("⚙️ Assembly", "assembly"),
            ("🚀 Run", "run")
        ]
        
        for text, phase in phases:
            btn = ttk.Button(self.middle_frame, text=text, 
                            command=lambda p=phase: self.run_phase(p),
                            style='Phase.TButton')
            btn.pack(side=tk.LEFT, padx=3)
            self.phase_btns.append(btn)
        
        # Input area with label
        input_label = tk.Label(self.bottom_frame, text="Source Code", bg=self.bg_color, 
                              fg=self.text_fg, font=('Segoe UI', 10, 'bold'))
        input_label.pack(anchor=tk.W)
        
        self.input_text = scrolledtext.ScrolledText(
            self.bottom_frame, 
            height=15, 
            width=80,
            bg=self.text_bg,
            fg=self.text_fg,
            insertbackground=self.text_fg,
            selectbackground=self.highlight_color,
            font=('Consolas', 10),
            padx=10,
            pady=10,
            relief=tk.FLAT,
            bd=0
        )
        self.input_text.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Output area with label and clear button
        output_header = tk.Frame(self.bottom_frame, bg=self.bg_color)
        output_header.pack(fill=tk.X)
        
        output_label = tk.Label(output_header, text="Compiler Output", bg=self.bg_color, 
                               fg=self.text_fg, font=('Segoe UI', 10, 'bold'))
        output_label.pack(side=tk.LEFT, anchor=tk.W)
        
        self.clear_output_btn = ttk.Button(output_header, text="Clear Output", command=self.clear_output)
        self.clear_output_btn.pack(side=tk.RIGHT)
        
        self.output_text = scrolledtext.ScrolledText(
            self.bottom_frame, 
            height=15, 
            width=80,
            bg=self.text_bg,
            fg=self.text_fg,
            state='normal',
            insertbackground=self.text_fg,
            selectbackground=self.highlight_color,
            font=('Consolas', 10),
            padx=10,
            pady=10,
            relief=tk.FLAT,
            bd=0
        )
        self.output_text.pack(fill=tk.BOTH, expand=True)
        
        # Status bar
        self.status_bar = tk.Label(root, text="Ready", bd=0, relief=tk.SUNKEN, anchor=tk.W, 
                                 bg=self.status_bg, fg=self.status_fg, font=('Segoe UI', 9))
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def configure_styles(self):
        """Configure custom ttk styles for dark theme"""
        style = ttk.Style()
        
        # General button style
        style.configure('TButton',
                      background=self.button_color,
                      foreground=self.text_fg,
                      bordercolor=self.bg_color,
                      darkcolor=self.bg_color,
                      lightcolor=self.bg_color,
                      relief=tk.FLAT,
                      font=('Segoe UI', 9),
                      padding=5)
        
        style.map('TButton',
                 background=[('active', self.button_active)],
                 relief=[('pressed', 'sunken')])
        
        # Phase button style
        style.configure('Phase.TButton',
                      background=self.button_color,
                      foreground=self.text_fg,
                      font=('Segoe UI', 9, 'bold'))
        
        # Accent button style (for important actions)
        style.configure('Accent.TButton',
                      background=self.accent_color,
                      foreground='white',
                      font=('Segoe UI', 9, 'bold'))
        
        style.map('Accent.TButton',
                background=[('active', '#6ba6d9')])
        
        # Scrollbar style
        style.configure('Vertical.TScrollbar',
                       background=self.button_color,
                       troughcolor=self.bg_color,
                       bordercolor=self.bg_color,
                       arrowcolor=self.text_fg,
                       gripcount=0,
                       relief=tk.FLAT)
        
        style.map('Vertical.TScrollbar',
                background=[('active', self.button_active)])

    def open_file(self):
        fname = filedialog.askopenfilename(filetypes=[("MiniLang Files", "*.mini"), ("All Files", "*.*")])
        if fname:
            try:
                with open(fname, 'r', encoding='utf-8') as f:
                    code = f.read()
                self.input_text.delete(1.0, tk.END)
                self.input_text.insert(tk.END, code)
                self.filename = fname
                self.file_label.config(text=f"File: {os.path.basename(fname)}")
                self.status_bar.config(text=f"Loaded: {fname}")
            except Exception as e:
                messagebox.showerror("Error", f"Could not open file:\n{str(e)}")

    def save_file(self):
        if not self.filename:
            self.filename = filedialog.asksaveasfilename(
                defaultextension=".mini",
                filetypes=[("MiniLang Files", "*.mini"), ("All Files", "*.*")])
            if not self.filename:
                return
        
        try:
            with open(self.filename, 'w', encoding='utf-8') as f:
                code = self.input_text.get(1.0, tk.END)
                f.write(code)
            self.file_label.config(text=f"File: {os.path.basename(self.filename)}")
            self.status_bar.config(text=f"Saved: {self.filename}")
            messagebox.showinfo("Success", "File saved successfully")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save file:\n{str(e)}")

    def clear_code(self):
        self.input_text.delete(1.0, tk.END)
        self.filename = None
        self.file_label.config(text="No file loaded")
        self.status_bar.config(text="Editor cleared")

    def clear_output(self):
        self.output_text.delete(1.0, tk.END)
        self.status_bar.config(text="Output cleared")

    def run_phase(self, phase):
        code = self.input_text.get(1.0, tk.END).strip()
        if not code:
            messagebox.showerror("Error", "No source code provided.")
            return

        self.status_bar.config(text=f"Running {phase} phase...")
        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(tk.END, f"Running {phase} phase...\n")
        self.root.update()

        # Write code to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mini", mode="w", encoding="utf-8") as tmp:
            tmp.write(code)
            tmp_filename = tmp.name

        try:
            # Run the C++ compiler executable
            result = subprocess.run([CPP_EXECUTABLE, tmp_filename], capture_output=True, text=True, timeout=10)
            output = result.stdout

            # Filter output for each phase
            phase_map = {
                "tokenize": "=== Lexical Analysis (Tokenization) ===",
                "parse": "=== Syntax Analysis (Parsing) ===",
                "semantic": "=== Semantic Analysis ===",
                "tac": "=== Intermediate Code Generation ===",
                "assembly": "=== Assembly Code Generation ===",
                "run": "=== Output of Input Code ==="
            }
            marker = phase_map[phase]
            if marker not in output:
                self.output_text.delete(1.0, tk.END)
                self.output_text.insert(tk.END, "Phase not found in compiler output.")
                self.status_bar.config(text=f"{phase} phase completed with no output")
                return

            # Extract relevant section
            lines = output.splitlines()
            start = [i for i, l in enumerate(lines) if marker in l]
            if not start:
                self.output_text.delete(1.0, tk.END)
                self.output_text.insert(tk.END, "Could not find phase output.")
                self.status_bar.config(text=f"{phase} phase completed with no output")
                return
                
            start = start[0]
            # Show until next === or end
            end = next((i for i in range(start+1, len(lines)) if lines[i].startswith("===")), len(lines))
            phase_output = "\n".join(lines[start:end])

            self.output_text.delete(1.0, tk.END)
            self.output_text.insert(tk.END, phase_output)
            self.status_bar.config(text=f"{phase} phase completed successfully")
            
        except subprocess.TimeoutExpired:
            self.output_text.delete(1.0, tk.END)
            self.output_text.insert(tk.END, "Compiler timed out after 10 seconds")
            self.status_bar.config(text=f"{phase} phase timed out")
        except Exception as e:
            self.output_text.delete(1.0, tk.END)
            self.output_text.insert(tk.END, f"Error running compiler: {e}")
            self.status_bar.config(text=f"Error during {phase} phase")
        finally:
            os.unlink(tmp_filename)

if __name__ == "__main__":
    root = tk.Tk()
    
    # Set window icon if available
    try:
        root.iconbitmap('icon.ico')  # Replace with your icon file if available
    except:
        pass
    
    app = CompilerUI(root)
    
    # Center the window
    root.update_idletasks()
    width = root.winfo_width()
    height = root.winfo_height()
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry(f'{width}x{height}+{x}+{y}')
    
    root.mainloop()